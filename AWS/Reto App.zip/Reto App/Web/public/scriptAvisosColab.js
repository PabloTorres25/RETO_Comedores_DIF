const avisos = document.querySelectorAll('.aviso');
const btnAtendidoList = document.querySelectorAll('.btnAtendido');
const contenedorAvisos = document.querySelector('.avisos-container');

function obtenerAvisosPendientes() {
  fetch('/obtenerAvisosPendientes')
    .then(response => response.json())
    .then(data => {
      const contenedorAvisos = document.getElementById('aviso');

      // Limpiar el contenedor de avisos existentes
      contenedorAvisos.innerHTML = '';

      data.forEach(aviso => {
          const divAviso = document.createElement('div');
          divAviso.classList.add('aviso');
          divAviso.innerHTML = `
          <div class = "w3-col" style="width:20%">
            <h2>${aviso.tipoDeAviso}</h2>
          </div>
          <div class = "w3-col" style="width:20%">
            <p style="margin: 20px;">${aviso.nombreComedor}</p>
          </div>
          <div class = "w3-col" style="width:60%">
            <p style="margin: 20px;">${aviso.descripcion}</p>
          </div>
          `;
        
          // Agregar el div aviso al contenedor de avisos
          contenedorAvisos.appendChild(divAviso);

          
        });
    })
    .catch(error => {
      console.error('Error al obtener los avisos pendientes:', error);
    });
    
}

const mostrarMasBoton = document.getElementById("mostrarMas");
const descripcionParrafo = document.getElementById("textoDescripcion");


obtenerAvisosPendientes();
