const modalBtn = document.getElementById('modalBtn');
const closeBtn = document.querySelector('.closeIcon');
const borrarComedor = document.getElementById('okBtn');
const modal = document.querySelector('.modal');
//const passwordField = document.getElementById('passwordField').value.trim();


modalBtn.addEventListener('click', ()=> {
    modal.classList.add('active');
  });

closeBtn.addEventListener('click', ()=> {
    modal.classList.remove('active');
});

window.addEventListener('click', event => {
    if(event.target == modal) {
        modal.classList.remove('active');
    }
})

function borComedor() {
    // Obtener la contraseña ingresada por el usuario
    const enteredPassword = document.getElementById('passwordFieldUs').value;
    const nombre = nombreComedorField.value;

    // Comprobar si la contraseña está en el formato correcto
    if (enteredPassword === '') {
        alert("Por favor, ingresa una contraseña.");
    } else{
        
        console.log('detecté algo');

        const data = { contrasena: enteredPassword };
    
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/verificarContrasena');
        xhr.setRequestHeader('Content-type', 'application/json');
        xhr.onload = () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    console.log('Contraseña correcta. Puedes borrar el comedor.');
                    const xhrB = new XMLHttpRequest();
                    xhrB.open('DELETE', '/borrarComedor');
                    xhrB.setRequestHeader('Content-type', 'application/json');
                    xhrB.onload = () => {
                        const responseB = JSON.parse(xhrB.responseText);
                    };
                    alert("Comedor Eliminado.");
                    xhrB.send(JSON.stringify({ "nombre" : nombre }));
                    // xhrB.send(JSON.stringify({ "nombre" : "Pene" }));
                    modal.classList.remove('active');
                    // Lógica para borrar el comedor aquí
                    window.location.reload();
                } else {
                    alert("La contraseña es incorrecta. Inténtalo de nuevo.");
                }
            } else {
                alert("Error al conectar con el servidor. Inténtalo de nuevo más tarde.");
            }
        };
        xhr.send(JSON.stringify(data));
    }
}

function actComedor(){
    
     const idComedor = idComedorField.value;
     const nombreComedor = nombreComedorField.value;
     const contrasena = passwordField.value;
     const calle = calleField.value;
     const colonia = coloniaField.value;
     const municipio = municipioField.value;
     const telefono = telefonoField.value;
     const nombreRP = nombreRepresentanteField.value;
     const telefonoRP = telefonoRepresentanteField.value;

    const xhrA = new XMLHttpRequest();
        xhrA.open('PUT', '/modificarComedor');
        xhrA.setRequestHeader('Content-type', 'application/json');
        xhrA.onload = () => {
            if (xhrA.status === 201) {
                alert("Los datos del comedor se han actualizado correctamente.")
                window.location.reload();
            } else{
                alert("Error al actualizar los datos del comedor.")
            }
        };
        // xhrA.send(JSON.stringify(nombreComedor, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP));
        xhrA.send(JSON.stringify({"nombre" :  nombreComedor, "contrasena": contrasena, "calle": calle, "colonia": colonia, "municipio": municipio, "telefono": telefono, "nombreRP": nombreRP, "telefonoRP": telefonoRP, "idComedor": idComedor}));

}

document.getElementById('searchButton').addEventListener('click', function() {
  const searchTerm = document.getElementById('search').value;

  // Realiza una solicitud AJAX para buscar en el API
  fetch('/obtenerComedores')
    .then(response => response.json())
    .then(data => {
      // Filtra los resultados basados en el término de búsqueda
      const filteredResults = data.filter(comedor => {
        return comedor.nombre.toLowerCase().includes(searchTerm.toLowerCase());
      });

      const resultsDiv = document.getElementById('results');
      const noComedorMessage = document.getElementById('noComedor');

      if (filteredResults.length === 0) {
        noComedorMessage.style.display = 'block';
        resultsDiv.style.display = 'none';
      } else {
        noComedorMessage.style.display = 'none';
        resultsDiv.style.display = 'block';
        resultsDiv.innerHTML = ''; // Limpia los resultados anteriores
        filteredResults.forEach(comedor => {
          const resultElement = document.createElement('div');
          resultElement.textContent = `${comedor.nombre},  ${comedor.calle}, ${comedor.colonia}, ${comedor.municipio}`;
          
          // Agrega un atributo data-comedor con la información del comedor
          resultElement.setAttribute('data-comedor', JSON.stringify(comedor));
          
          // Agrega un evento de clic para seleccionar el comedor
          resultElement.addEventListener('click', function() {
            const comedorData = JSON.parse(this.getAttribute('data-comedor'));
            // Llama a una función para autorellenar los campos
            autorellenarCampos(comedorData);
          });
          
          resultsDiv.appendChild(resultElement);
        });
      }
    })
    .catch(error => {
      console.error('Error al buscar:', error);
    });
});

function autorellenarCampos(comedorData) {
  // Llena los campos con la información del comedor seleccionado
  document.getElementById('idComedorField').value = comedorData.idComedor;
  document.getElementById('nombreComedorField').value = comedorData.nombre;
  document.getElementById('passwordField').value = comedorData.contrasena;
  document.getElementById('calleField').value = comedorData.calle;
  document.getElementById('coloniaField').value = comedorData.colonia;
  document.getElementById('municipioField').value = comedorData.municipio;
  document.getElementById('telefonoField').value = comedorData.telefono;
  document.getElementById('nombreRepresentanteField').value = comedorData.nombreRP;
  document.getElementById('telefonoRepresentanteField').value = comedorData.telefonoRP;
  
  
  // Opcional: Oculta los resultados después de seleccionar un comedor
  document.getElementById('results').innerHTML = '';
  results.style.display='none';
}