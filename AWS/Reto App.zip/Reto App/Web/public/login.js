
/*function logIn() {
  const loginForm = document.querySelector('.login form');

  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const correo = loginForm.correo.value;
    const contrasena = md5(loginForm.contrasena.value);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/login');
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.onload = () => {
      if (xhr.status === 200) {
        const response = JSON.parse(xhr.responseText);
        if (response.success) {
          // redirigir al usuario a la página de inicio
          window.location.href = '/home.html';
          console.log('BIEN');
        } else{
          // mostrar mensaje de error al usuario
          //alert('Error al iniciar sesión. Verifique sus credenciales e intente nuevamente.');
          loginError.style.display='block';
          console.log('MAL');
        }
      } else {
        // mostrar mensaje de error al usuario
        alert('Error al conectarse al servidor. Intente nuevamente más tarde.');
      }
    };
    xhr.send(JSON.stringify({ correo, contrasena }));
  });
}*/

function logIn() {
  console.log('hago la función');
  const loginForm = document.querySelector('.login form');

  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const usuario = loginForm.usuario.value;
    const contrasena = loginForm.contrasena.value;
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/login');
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.onload = () => {
      console.log('response status:', xhr.status);
      console.log('response body:', xhr.responseText);
      if (xhr.status === 200) {
        const response = JSON.parse(xhr.responseText);
        console.log('entro a el primer if');
        if (response.success) {
          console.log('segundo if');
          // redirigir al usuario a la página de inicio
          if (response.role === 'admin') {
            window.location.href = '/admin.html';
          } else if (response.role === 'colaborador') {
            window.location.href = '/home.html';
          }
        } else{
          // mostrar mensaje de error al usuario
          //alert('Error al iniciar sesión. Verifique sus credenciales e intente nuevamente.');
          loginError.style.display='block';
          console.log('MAL');
        }
      } else {
        // mostrar mensaje de error al usuario
        alert('Error al conectarse al servidor. Intente nuevamente más tarde.');
      }
    };
    xhr.send(JSON.stringify({ usuario, contrasena }));
  });
}



