const wrapper = document.querySelector('.wrapper');
const boxAdmin = document.querySelector('.boxAdmin')
const loginLink = document.querySelector('.login-link');
const linkComedor = document.querySelector('.link-comedor');
const registerLink = document.querySelector('.register-link');
const registrarComedor = document.querySelector('.registrar-comedor')

registrarComedor.addEventListener('click', ()=> {
  boxAdmin.classList.add('active1');
});

registerLink.addEventListener('click', ()=> {
  boxAdmin.classList.add('active');
});

linkComedor.addEventListener('click', ()=> {
  boxAdmin.classList.remove('active1');
});

loginLink.addEventListener('click', ()=> {
  boxAdmin.classList.remove('active');
});

//Función para hacer LogOut

function logOut() {

  localStorage.removeItem('token');

  window.location.href = '/index.html';
}

//Función Mostrar Contraseña
function mostrarContrasena(){
      var tipo = document.getElementById("password");
      if(tipo.type == "password"){
          tipo.type = "text";
      }else{
          tipo.type = "password";
      }
  }