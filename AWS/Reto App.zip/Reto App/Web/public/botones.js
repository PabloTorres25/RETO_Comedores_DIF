const contenedorBotones = document.getElementById('contenedor-botones');
const contenedorToast = document.getElementById('contenedor-toast');
const btnError = document.getElementById("btnError");
const btnWarning = document.getElementById("btnWarning");

// Event listener para detectar click en los botones
contenedorBotones.addEventListener('click', (e) => {
	e.preventDefault();

	const tipo = e.target.dataset.tipo;

	if (tipo === 'error') {
		agregarToast({ tipo: 'error', titulo: 'Error', descripcion: 'Hubo un error', autoCierre: true });
        let numeroErrores = parseInt(btnError.getAttribute("data-errores"));

        // Incrementa el número de errores si no es igual a 0
        if (numeroErrores > 0) {
            numeroErrores--;
        }

        // Actualiza el atributo data-errores y el texto del botón
        btnError.setAttribute("data-errores", numeroErrores);

        if (numeroErrores === 0) {
            btnError.style.display='none';
        } else {
            btnError.textContent = numeroErrores + " Avisos";
        }
	}
});

// Event listener para detectar click en los toasts
contenedorToast.addEventListener('click', (e) => {
	const toastId = e.target.closest('div.toast').id;

	if (e.target.closest('button.btn-cerrar')) {
		cerrarToast(toastId);
	}
});

// Función para cerrar el toast
const cerrarToast = (id) => {
	document.getElementById(id)?.classList.add('cerrando');
};

// Función para agregar la clase de cerrando al toast.
const agregarToast = ({ tipo, titulo, descripcion, autoCierre }) => {
	// Crear el nuevo toast
	const nuevoToast = document.createElement('div');

	// Agregar clases correspondientes
	nuevoToast.classList.add('toast');
	nuevoToast.classList.add(tipo);
	if (autoCierre) nuevoToast.classList.add('autoCierre');

	// Agregar id del toast
	const numeroAlAzar = Math.floor(Math.random() * 100);
	const fecha = Date.now();
	const toastId = fecha + numeroAlAzar;
	nuevoToast.id = toastId;

	// Iconos
	const iconos = {
		error: `<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
								<path
									d="M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM8 4c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995A.905.905 0 0 1 8 4zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"
								/>
							</svg>`,
	};

	// Plantilla del toast
	const toast = `
		<div class="contenido">
			<div class="icono">
				${iconos[tipo]}
			</div>
			<div class="texto">
				<p class="titulo">${titulo}</p>
				<p class="descripcion">${descripcion}</p>
			</div>
		</div>
		<button class="btn-cerrar">
			<div class="icono">
				<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
					<path
						d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"
					/>
				</svg>
			</div>
		</button>
	`;

	// Agregar la plantilla al nuevo toast
	nuevoToast.innerHTML = toast;

	// Agregamos el nuevo toast al contenedor
	contenedorToast.appendChild(nuevoToast);

	// Función para menajera el cierre del toast
	const handleAnimacionCierre = (e) => {
		if (e.animationName === 'cierre') {
			nuevoToast.removeEventListener('animationend', handleAnimacionCierre);
			nuevoToast.remove();
		}
	};

	if (autoCierre) {
		setTimeout(() => cerrarToast(toastId), 5000);
	}

	// Agregamos event listener para detectar cuando termine la animación
	nuevoToast.addEventListener('animationend', handleAnimacionCierre);
};

function setNumeroErrores() {
    const xhr = new XMLHttpRequest();
	xhr.open('GET', '/obtenerNumeroAvisos');
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.onload = () => {
		if (xhr.status === 200) {
			let numero = JSON.parse(xhr.responseText);
			if (numero != 0) {
				btnError.style.display='block';
			}
			btnError.setAttribute("data-errores", numero);
		    if (numero === 0) {
		        btnError.textContent = "Avisos";
		    } else {
		        btnError.textContent = numero + " Avisos";
		    }
		} else {
			alert("Error al conectar con el servidor")
		}
		
	}
	
	xhr.send();
}

function setTipoAviso() {
    const xhr = new XMLHttpRequest();
	xhr.open('GET', '/obtenerNumeroAvisos');
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.onload = () => {
		if (xhr.status === 200) {
			let numero = JSON.parse(xhr.responseText);
			if (numero != 0) {
				btnError.style.display='block';
			}
			btnError.setAttribute("data-errores", numero);
		    if (numero === 0) {
		        btnError.textContent = "Avisos";
		    } else {
		        btnError.textContent = numero + " Avisos";
		    }
		} else {
			alert("Error al conectar con el servidor")
		}
		
	}
	
	xhr.send();
}

setNumeroErrores();


function regresar(){
	window.location.href = "admin.html";

}

function regresarColab(){
	window.location.href = "home.html";

}

function avisosAtendidos(){
	window.location.href = "avisosAtendidos.html";

}

function avisosAtendidosColab(){
	window.location.href = "avisosAtendidosColab.html";

}

function avisosPendientesColab(){
	window.location.href = "avisosColab.html";

}

function logOut() {

  localStorage.removeItem('token');

  window.location.href = '/index.html';
}

function btnAvisos() {
	window.location.href = "avisos.html";
}