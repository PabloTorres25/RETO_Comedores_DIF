const avisos = document.querySelectorAll('.aviso');
const btnAtendidoList = document.querySelectorAll('.btnAtendido');
const contenedorAvisos = document.querySelector('.avisos-container');

function ocultarAvisoConAnimacion(aviso) {
    aviso.classList.add('oculto');
    setTimeout(() => {
        aviso.style.display = 'none';
    }, 500);
}

function cambiarEstadoAviso(idAviso) {
    const xhr = new XMLHttpRequest();
        xhr.open('PUT', '/modificarEstadoAviso');
        xhr.setRequestHeader('Content-type', 'application/json');
        xhr.onload = () => {
            if (xhr.status === 201) {
                // Comentar al final
                alert("El estado de ha cambiado correctamente.")
            } else{
                alert("Error al actualizar el estado del aviso.")
            }
        };
        xhr.send(JSON.stringify({"idAviso" : idAviso}));
}

function obtenerAvisosPendientes() {
  fetch('/obtenerAvisosPendientes')
    .then(response => response.json())
    .then(data => {
      const contenedorAvisos = document.getElementById('aviso');

      // Limpiar el contenedor de avisos existentes
      contenedorAvisos.innerHTML = '';

      data.forEach(aviso => {
          const divAviso = document.createElement('div');
          divAviso.classList.add('aviso');
          divAviso.innerHTML = `
          <div class = "w3-col" style="width:20%">
            <h2>${aviso.tipoDeAviso}</h2>
          </div>
          <div class = "w3-col" style="width:20%">
            <p style="margin: 20px;">${aviso.nombreComedor}</p>
          </div>
          <div class = "w3-col" style="width:50%">
            <p style="margin: 20px;">${aviso.descripcion}</p>
          </div>
          <div class = "w3-col" style="width:10%">
            <button class="btnAtendido">Atendido</button>
          </div>
          `;
        
          // Agregar el div aviso al contenedor de avisos
          contenedorAvisos.appendChild(divAviso);

          // Agregar un manejador de eventos click al botón "Atendido"
          divAviso.querySelector('.btnAtendido').addEventListener('click', () => {
            ocultarAvisoConAnimacion(divAviso);
            cambiarEstadoAviso(aviso.idAviso);
          });
        });
    })
    .catch(error => {
      console.error('Error al obtener los avisos pendientes:', error);
    });
    
}

const mostrarMasBoton = document.getElementById("mostrarMas");
const descripcionParrafo = document.getElementById("textoDescripcion");


obtenerAvisosPendientes();
