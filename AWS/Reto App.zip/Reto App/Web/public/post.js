/* global usuarioField nombreField emailField passwordField main endMessage result */

function validateRegistroForm() {
  const usuario = usuarioField.value.trim();
  const nombre = nombreField.value.trim();
  const password = passwordField.value.trim();
  const rol = rolField.value;

  if (usuario === '' || nombre === '' || password === '' || rol === 'Seleccione un rol') {
    // Mostrar un mensaje de error o hacer lo que desees para indicar que los campos son obligatorios.
    alert('Todos los campos son obligatorios');
    return false;
  }

  return true;
}

function saveData() {
  if (validateRegistroForm()) {
    const contrasenaBD = passwordField.value;
    const payLoad = JSON.stringify({
      usuario: usuarioField.value,
      nombre: nombreField.value,
      contrasena: passwordField.value,
      rol: rolField.value
    });

    const xhr = new XMLHttpRequest();
    xhr.onload = () => {
      if(xhr.status == 500){
        registroError.style.display='block';
      }else{
        alert('¡Tu registro quedó completado!');
        location.reload();
      }
    };

    xhr.open('POST', '/crearAdmin');
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(payLoad);
  }
}

function validateComedorForm() {
  const nombreComedor = nombreComedorField.value.trim();
  const contrasena = contraField.value.trim();
  const calle = calleField.value.trim();
  const colonia = coloniaField.value.trim();
  const municipio = municipioField.value.trim();
  const telefono = telefonoField.value.trim();
  const nombreRP = nombreRepresentanteField.value.trim();
  const telefonoRP = telefonoRepresentanteField.value.trim();

  if (nombreComedor === '' || contrasena === '' || calle === '' || colonia === '' || municipio === '' || telefono === '' || nombreRP === '' || telefonoRP === '') {
    // Mostrar un mensaje de error o hacer lo que desees para indicar que los campos son obligatorios.
    alert('Todos los campos son obligatorios');
    return false;
  }

  return true;
}

function saveComedor() {
  if (validateComedorForm()){
    const payLoad = JSON.stringify({
      nombre: nombreComedorField.value,
      contrasena: contraField.value,
      calle: calleField.value,
      colonia: coloniaField.value,
      municipio: municipioField.value,
      telefono: telefonoField.value,
      nombreRP: nombreRepresentanteField.value,
      telefonoRP: telefonoRepresentanteField.value
    });

    const xhr = new XMLHttpRequest();
    xhr.onload = () => {
      if(xhr.status == 500){
        comedorError.style.display='block';
      }else{
        alert('¡El registro del Comedor quedó completado!');
        location.reload();
      }
    };

    xhr.open('POST', '/crearComedor');
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(payLoad);
  }
}