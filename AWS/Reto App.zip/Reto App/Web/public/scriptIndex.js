const wrapper = document.querySelector('.wrapper');
const boxAdmin = document.querySelector('.boxAdmin')
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');

btnPopup.addEventListener('click', ()=> {
  wrapper.classList.add('active-popup');
  textoInicio.style.display='none';
});

registerLink.addEventListener('click', ()=> {
  boxAdmin.classList.add('active');
});

loginLink.addEventListener('click', ()=> {
  boxAdmin.classList.remove('active');
});

iconClose.addEventListener('click', ()=> {
    wrapper.classList.remove('active-popup');
    setTimeout(function(){
        textoInicio.style.display='block';
    }, 500);
});
