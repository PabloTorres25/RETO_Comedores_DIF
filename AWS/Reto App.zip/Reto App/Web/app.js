// http://44.220.12.52:8080

// Declarar dependencias
const https = require('https');
const fs = require('fs');
const express = require('express');
const path = require('path');
const mysql = require('mysql');
const app = express();

const options = {
  key: fs.readFileSync('/etc/letsencrypt/live/comedores-dif.serveftp.com/privkey.pem'),
  cert: fs.readFileSync('/etc/letsencrypt/live/comedores-dif.serveftp.com/fullchain.pem')
};

const server = https.createServer(options, app);

const PORT = 443;

app.set('port', PORT);

// middlewares
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Creamos la conexión con la BD DIF
const db = mysql.createConnection({
  host: 'localhost',
  database: 'DIF',
  user: 'root',
  password: 'didif69'
});

db.connect(err => {
  if (err) {
    console.error('No se pudo conectar a la base de datos.');
    throw err;
  } else {
    console.log('Conexión exitosa a la base de datos.');
  }
});

// Recurso Página principal
app.get('/', function(req, res) {
  res.sendFile(__dirname + '/public/index.html');
});


// POST:---------------------------------------------------------------------------------------------------------------------------------------------

// Recurso para crear un comedor
app.post('/crearComedor', (req, res) => {   //Probado
  let { nombre, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP } = req.body;
  db.query('INSERT INTO comedor (nombre, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [nombre, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Comedor creado.\n`);
      }
    });
});

// Recurso para crear un administrador
app.post('/crearAdmin', (req, res) => {   //Probado
  let { usuario, contrasena, nombre, rol } = req.body;
  db.query('INSERT INTO administrador (usuario, contrasena, nombre, rol) VALUES (?, ?, ?, ?)',
    [usuario, contrasena, nombre, rol],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Administrador creado.\n`);
      }
    });
});


// Recurso para crear un beneficiario
app.post('/agregarBeneficiario', (req, res) => {    //Probado
  let { nombre, curp, fechaNacimiento, sexo, calle, colonia, municipio } = req.body;
  db.query('INSERT INTO beneficiario (nombre, curp, fechaNacimiento, sexo, calle, colonia, municipio) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [nombre, curp, fechaNacimiento, sexo, calle, colonia, municipio ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Beneficiario creado.\n`);
      }
    });
});

//Obtener idBeneficiario del beneficiario solicitado
app.post('/obtenerIdBeneficiario', (req, res) => {
  const nombre = req.query.nombre;
  const fechaNacimiento = req.query.fechaNacimiento;
  db.query('SELECT idBeneficiario from beneficiario WHERE nombre = ? and fechaNacimiento = ?;',
    [nombre, fechaNacimiento],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
          const idBeneficiario = result[0].idBeneficiario;
          res.type('text')
          .status(200) // Cambiar a 200 para indicar éxito
          .send(idBeneficiario.toString());
      }
    });
});


// Recurso para crear un voluntario
app.post('/agregarVoluntario', (req, res) => {    //Probado
  let { nombre, fechaNacimiento, telefono } = req.body;
  db.query('INSERT INTO voluntario (nombre, fechaNacimiento, telefono) VALUES (?, ?, ?)',
    [nombre, fechaNacimiento, telefono],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Voluntario creado.\n`);
      }
    });
});


// Recurso para agregar personal de un comedor
app.post('/agregarPersonal', (req, res) => {    //Probado
  let { idComedor, idVoluntario, rol } = req.body;
  db.query('INSERT INTO personalComedor (idComedor, idVoluntario, rol) VALUES (?, ?, ?)',
    [idComedor, idVoluntario, rol],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Personal agregado.\n`);
      }
    });
});


// Recurso para crear una asistencia
app.post('/registrarAsistencia', (req, res) => { // Probado
  let { idComedor, idBeneficiario, fecha, comidaPagada, presente } = req.body;
  db.query('INSERT INTO asistencia (idComedor, idBeneficiario, fecha, comidaPagada, presente) VALUES (?, ?, ?, ?, ?)',
    [idComedor, idBeneficiario, fecha, comidaPagada, presente],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Asistencia tomada.\n`);
      }
    });
});


// Recurso para crear un aviso
app.post('/registrarAviso', (req, res) => { // Probado
  let { idComedor, idTipoAviso, fecha, descripcion } = req.body;
  db.query('INSERT INTO aviso (idComedor, idTipoAviso, fecha, descripcion) VALUES (?, ?, ?, ?)',
    [idComedor, idTipoAviso, fecha, descripcion],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Aviso registrado.\n`);
      }
    });
});


// Recurso para crear una familia
app.post('/registrarFamilia', (req, res) => { // Probado
  let { nombre } = req.body;
  db.query('INSERT INTO familia (nombre) VALUES (?);',
    [ nombre ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Familia registrada.\n`);
      }
    });
});




// Recurso para crear una familia
app.post('/registrarFamiliaBeneficiario', (req, res) => { // Probado
  let { idFamilia, idBeneficiario } = req.body;
  db.query('INSERT INTO familiaBeneficiario (idFamilia, idBeneficiario) VALUES (?, ?);',
    [ idFamilia, idBeneficiario ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Beneficiario Familia Registrado.\n`);
      }
    });
});

// Recurso para agregar la condición de un beneficiario
app.post('/agregarCondicionBeneficiario', (req, res) => {    //Probado
  let { idBeneficiario, idCondicion } = req.body;
  db.query('INSERT INTO beneficiarioCondicion (idBeneficiario, idCondicion) VALUES (?, ?);',
    [idBeneficiario, idCondicion],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Condición beneficiario creado.\n`);
      }
    });
});


// GETS ----------------------------------------------------------------------------------------------------------------------------

// Regresa idFamilia de acuerdo al nombre del beneficiario en INT.
app.get('/obtenerIdFamilia', (req, res) => { // Probado
  let { nombre } = req.body;
  db.query('SELECT idFamilia from familiaBeneficiario WHERE idBeneficiario = (SELECT idBeneficiario from beneficiario WHERE nombre = ?);',
    [nombre],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
          let resultado = result[0]
          res.json(resultado["idFamilia"]);
      }
    });
});

app.get('/obtenerIdFamiliaCreada', (req, res) => { // Probado
  const nombre = req.query.nombre;
  //const { nombre } = req.body;
  db.query('SELECT idFamilia from familia WHERE nombre = ?;',
    [nombre],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        const idFamilia = result[0].idFamilia;
        res.type('text')
        .status(200) // Cambiar a 200 para indicar éxito
        .send(idFamilia.toString());
      }
    });
});

// Obtener todos los beneficiarios
app.post('/obtenerBeneficiarios', (req, res) => { // Probado
  db.query('SELECT * from beneficiario;',
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(result);
      }
    });
});

// Obtener datos de todos los comedores
app.get('/obtenerComedores', (req, res) => { // Probado
  db.query('SELECT * from comedor;',
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        if (result.length > 0) {
          res.type('text')
            .status(200) // Cambiar a 200 para indicar éxito
            .send(result);
        }
        else {
        res.status(404).send('Comedor no encontrado'); // Cambiar a 404 si el comedor no existe
      }
      }
    });
});

// GET voluntarios
app.get('/obtenerVoluntarios', (req, res) => { // Probado
  let { idComedor } = req.body; 
  db.query('SELECT idVoluntario, nombre from voluntario WHERE idVoluntario in (SELECT idVoluntario from personalComedor where idComedor = ?);',
  [idComedor],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(result);
      }
    });
});

app.post('/obtenerVoluntario', (req, res) => { // Probado
  const nombre = req.query.nombre;
  //let { nombre } = req.body; 
  db.query('SELECT idVoluntario from voluntario WHERE nombre = ?;',
  [ nombre ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        if (result.length > 0) {
          const idVoluntario = result[0].idVoluntario;
          res.type('text')
            .status(200) // Cambiar a 200 para indicar éxito
            .send(idVoluntario.toString());
        }
        else {
        res.status(404).send('Voluntario no encontrado'); // Cambiar a 404 si el comedor no existe
      }
    }
    });
});


app.get('/obtenerComedor', (req, res) => {
  const nombre = req.query.nombre; // Usar req.query para obtener el parámetro "nombre"
  db.query('SELECT idComedor from comedor WHERE nombre = ?;', [nombre], (err, result) => {
    if (err) {
      res.status(500).json(err);
    } else {
      if (result.length > 0) {
        const idComedor = result[0].idComedor;
        res.type('text')
          .status(200) // Cambiar a 200 para indicar éxito
          .send(idComedor.toString()); // Enviar idComedor como cadena de texto
      } else {
        res.status(404).send('Comedor no encontrado'); // Cambiar a 404 si el comedor no existe
      }
    }
  });
});

// GET avisos pendientes:
app.get('/obtenerAvisosPendientes', (req, res) => { // Probado
  db.query('SELECT idAviso, (SELECT nombre FROM comedor WHERE comedor.idComedor = aviso.idComedor) AS nombreComedor, (SELECT nombreTipoAviso FROM tipoAviso WHERE tipoAviso.idTipoAviso = aviso.idTipoAviso) AS tipoDeAviso, fecha, descripcion FROM aviso WHERE estado = "Pendiente";',
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else { 
        res.type('text')
          .status(201)
          .send(result);
      }
    });
});


// GET avisos atendidos:
app.get('/obtenerAvisosAtendidos', (req, res) => { // Probado
  db.query('SELECT idAviso, (SELECT nombre FROM comedor WHERE comedor.idComedor = aviso.idComedor) AS nombreComedor, (SELECT nombreTipoAviso FROM tipoAviso WHERE tipoAviso.idTipoAviso = aviso.idTipoAviso) AS tipoDeAviso, fecha, descripcion FROM aviso WHERE estado = "Atendido";',
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else { 
        res.type('text')
          .status(201)
          .send(result);
      }
    });
});

app.get('/obtenerNumeroAvisos', (req, res) => {
  db.query('SELECT COUNT(*) AS numero from aviso WHERE estado = "Pendiente";',
  (err, result) => {
    if (err) {
      res.status(500).json(err);
    } else {
          let resultado = result[0];
          res.status(200).json(resultado["numero"]);
    }
  });
});


// DELETES ----------------------------------------------------------------------------------------------------------------------------

// Recurso que borra comedor por su nombre
app.delete('/borrarComedor', (req, res) => { // Probado
  let { nombre } = req.body;
  db.query('DELETE FROM comedor WHERE nombre = ?',
    [nombre],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(204);
      }
    });
});

// Delete Voluntario con idVoluntario y idComedor
app.delete('/borrarVoluntario', (req, res) => { // Probado
  let { idVoluntario, idComedor } = req.body;
  db.query('CALL BorrarVoluntarios(?, ?);',
    [idVoluntario, idComedor],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(204)
          .send(`Voluntario borrado.\n`);
      }
    });
});


// PUTS ----------------------------------------------------------------------------------------------------------------------------

// En cuanto se meta a "modificar comedor", se mande a GET el id del comedor.
app.put('/modificarComedor', (req, res) => { // Probado
  let {nombre, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP, idComedor } = req.body;
  db.query('UPDATE comedor SET nombre = ?, contrasena = ?, calle = ?, colonia = ?, municipio = ?, telefono = ?, nombreRP = ?, telefonoRP = ?  WHERE idComedor = ?;',
    [nombre, contrasena, calle, colonia, municipio, telefono, nombreRP, telefonoRP, idComedor ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else { 
          res.type('text')
          .status(201)
          .send(`Comedor modificado.\n`);
      }
    });
});

// Update estado del aviso a "Atendido", llamar cuando en la PW se marque como atendido.
app.put('/modificarEstadoAviso', (req, res) => { // Probado
  let { idAviso } = req.body;
  db.query('UPDATE aviso SET estado = "Atendido" WHERE idAviso = ?;',
    [idAviso], 
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
          res.type('text')
          .status(201)
          .send(`Aviso cambiado a Atendido.\n`);
      }
    });
});



// LOGIN Comedores

app.post('/loginComedor', (req, res) => {
  const { nombre, contrasena } = req.body;
  db.query('SELECT idComedor FROM comedor WHERE nombre = ?',
  [nombre],
  (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).send('Error al obtener datos de comedor de la base de datos');
    } else {
      // Comedor existe:
      if (result.length > 0) {
        db.query('SELECT contrasena from comedor where nombre = ?',
        [nombre],
        (err, result) => {
          if (err) {
            console.log(err);
            res.status(500).send('Error al obtener datos de comedor de la base de datos');
          } else {
            let resultado = result[0];
            if (resultado["contrasena"] === contrasena) {
              res.status(207).send('Login de comedor exitoso');
            } else {
              res.status(401).send('Contraseña inválida');
            }
          }
        });
      } else {
        res.status(404).send('Comedor no encontrado');
      }
    }
  });
});


// Recursos de página web


app.post('/login', (req, res) => {
  const usuario = req.body.usuario;
  const contrasena = req.body.contrasena;

  // Realizar consulta a la base de datos para verificar si el correo y la contraseña son correctos
  db.query('SELECT * FROM administrador WHERE usuario = ? AND contrasena = ?', [usuario, contrasena], (error, results) => {
    if (error) {
      // Si hay un error al realizar la consulta, responder con { success: false } y registrar el error en la consola
      console.error(error);
      res.json({ success: false });
    } else {
      if (results.length > 0) {
        // Si se encuentra un registro que coincide con las credenciales, responder con { success: true }
        const rol = results[0].rol;
        // Verificar si el rol es "administrador" o "colaborador" y responder en consecuencia
        if (rol === 'Administrador') {
          res.json({ success: true, role: 'admin' });
        } else if (rol === 'Colaborador') {
          res.json({ success: true, role: 'colaborador' });
        } else {
          res.json({ success: false });
        }
      } else {
        // Si no se encuentra un registro que coincida con las credenciales, responder con { success: false }
        res.json({ success: false });
      }
    }
  });
});

app.post('/verificarContrasena', (req, res) => {
  const contrasena = req.body.contrasena;

  // Realizar consulta a la base de datos para verificar si el correo y la contraseña son correctos
  db.query('SELECT * FROM administrador WHERE contrasena = ?', [contrasena], (error, results) => {
    if (error) {
      // Si hay un error al realizar la consulta, responder con { success: false } y registrar el error en la consola
      console.error(error);
      res.json({ success: false });
    } else {
      if (results.length > 0) {
        // Si se encuentra un registro que coincide con las credenciales, responder con { success: true }
        const rol = results[0].rol;
        // Verificar si el rol es "administrador" o "colaborador" y responder en consecuencia
        if (rol === 'Administrador') {
          res.json({ success: true, role: 'admin' });
        } else if (rol === 'Colaborador') {
          res.json({ success: true, role: 'colaborador' });
        } else {
          res.json({ success: false });
        }
      } else {
        // Si no se encuentra un registro que coincida con las credenciales, responder con { success: false }
        res.json({ success: false });
      }
    }
  });
});

// Recursos INVENTARIO:

// INGREDIENTE:

// GET todos los ingredientes como una lista de strings
app.get('/obtenerIngredientes', (req, res) => { // Probado
  db.query('SELECT nombre from ingrediente;',
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
          let lista = []
          for (let i = 0 ; i < result.length ; i++){
            lista.push(result[i]["nombre"])
          }
          res.json(lista);
      }
    });
});

// GET el ingrediente con idIngrediente
app.get('/obtenerIngrediente', (req, res) => { // 
  let { idIngrediente } = req.body;
  db.query('SELECT nombre from ingrediente WHERE idIngrediente = ?;',
    [ idIngrediente ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
          res.type('text')
          .status(201)
          .send(result);
      }
    });
});

// LOTE:
// GET con idComedor, el que ya tenemos cuando estamos en un comedor en la app
app.get('/obtenerLoteComedor', (req, res) => { // Probado
  const { idComedor } = req.body;
  db.query('SELECT idIngrediente, caducidad, cantidad, tipoCantidad  from ingrediente WHERE idComedor = ? AND estado = "Activo";',
    [idComedor],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else { 
        res.type('text')
          .status(201)
          .send(result);
      }
    });
});

// POST: 
app.post('/registrarLote', (req, res) => { // 
  let { idComedor, nombreIng, caducidad, cantidad, tipoCantidad } = req.body;
  db.query('INSERT INTO lote (idComedor, idIngrediente, caducidad, cantidad, tipoCantidad) VALUES (?, (SELECT idIngrediente FROM ingrediente WHERE nombre = ?), ?, ?, ?);',
    [ idComedor, nombreIng, caducidad, cantidad, tipoCantidad ],
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.type('text')
          .status(201)
          .send(`Lote Registrado.\n`);
      }
    });
});

// PUT: Cambiar estado
// Crear trigger con el count de los estados "Caducos"
app.put('/modificarEstadoLote', (req, res) => { // 
  let { idLote } = req.body;
  db.query('UPDATE lote SET estado = "Caduco" WHERE idLote = ?;',
    [idLote], 
    (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else { 
          res.type('text')
          .status(201)
          .send(`Aviso cambiado a Caduco.\n`);
      }
    });
});
  
  
server.listen(PORT, () => {
  console.log(`HTTPS server listening on port ${PORT}`);
});