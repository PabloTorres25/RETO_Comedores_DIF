import csv

# Nombre del archivo de entrada y salida
archivo_entrada = 'administrador.csv'
archivo_salida = 'salida_administrador.csv'

# Abre el archivo de entrada y el archivo de salida
with open(archivo_entrada, 'r') as entrada, open(archivo_salida, 'w', newline='') as salida:
    lector = csv.reader(entrada, delimiter=',')
    escritor = csv.writer(salida, delimiter=',', quoting=csv.QUOTE_MINIMAL)

    for fila in lector:
        nueva_fila = []  # Aquí almacenaremos las celdas individuales

        for celda in fila:
            # Dividir la celda en campos utilizando el espacio como separador
            campos = celda.split()
            nueva_fila.extend(campos)  # Agregar los campos a la nueva fila

        # Escribir la nueva fila en el archivo de salida
        escritor.writerow(nueva_fila)

print(f"El archivo '{archivo_salida}' ha sido creado con los datos separados en diferentes celdas.")
