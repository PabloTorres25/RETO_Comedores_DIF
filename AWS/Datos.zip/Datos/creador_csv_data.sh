#!/bin/bash

# Archivo de entrada que se vigilará
archivo_vigilado="beneficiario.csv"

# Comando para ejecutar cuando cambie el archivo
comando_ejecutar="python3 creador_csv.py"

# Inicia la vigilancia del archivo
while true; do
    # Utiliza inotifywait para detectar cambios en el archivo
    inotifywait -e modify "$archivo_vigilado"

    # Cuando el archivo cambia, ejecuta el comando
    echo "El archivo $archivo_vigilado ha cambiado. Ejecutando el comando..."
    $comando_ejecutar
done