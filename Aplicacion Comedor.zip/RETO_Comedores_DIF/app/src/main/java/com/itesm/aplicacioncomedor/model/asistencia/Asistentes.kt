package com.itesm.aplicacioncomedor.model.asistencia

data class Asistentes(
    val nombre: String,
    val edad: Int
)
