package com.itesm.aplicacioncomedor.viewmodel

import androidx.lifecycle.ViewModel

class FamiliaresRegistradosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}