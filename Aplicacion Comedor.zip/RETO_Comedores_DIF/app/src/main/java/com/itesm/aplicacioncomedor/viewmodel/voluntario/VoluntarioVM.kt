package com.itesm.aplicacioncomedor.viewmodel.voluntario

import androidx.lifecycle.ViewModel

class VoluntarioVM : ViewModel() {

}