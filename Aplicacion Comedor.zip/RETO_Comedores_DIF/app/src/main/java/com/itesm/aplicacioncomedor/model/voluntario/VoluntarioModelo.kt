package com.itesm.aplicacioncomedor.model.voluntario

class VoluntarioModelo {

}