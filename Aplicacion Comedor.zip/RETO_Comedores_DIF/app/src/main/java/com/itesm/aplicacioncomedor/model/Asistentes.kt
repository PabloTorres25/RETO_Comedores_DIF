package com.itesm.aplicacioncomedor.model

data class Asistentes(
    val nombre: String,
    val edad: Int
)
