package com.itesm.aplicacioncomedor.viewmodel

import androidx.lifecycle.ViewModel

class FamiliaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}