package com.itesm.aplicacioncomedor.viewmodel

import androidx.lifecycle.ViewModel

class VoluntarioVM : ViewModel() {

}