package com.itesm.aplicacioncomedor.viewmodel.registro_nuevo

import androidx.lifecycle.ViewModel

class FamiliaresRegistradosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}