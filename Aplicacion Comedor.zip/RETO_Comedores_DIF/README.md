# RETO_Comedores_DIF
Primera Actualización: 2023-10-01 03:53pm
- Se movieron lso botones Fab de "Main Activity" a "fragment_asistencia", para facilitar que no se vean en otros fragmentos
- Se puso funcionalidad al Fab de reporte para que lleve a su fragmento
- Se corrigio un error en el "mobile_navigation", que te llevaba al archivo Kotlin de familiaresRegistrados y no a su layout

Segunda Actualización: 02-10-2023 01:37 pm
- Se cambió la interfaz de app_bar_main.xml donde se ajustó el toolbar 

Tercera Actualización: 02-10-2023 18:34 pm
- Se colocó la pantalla introductoria con el logo antes de mostrar el main activity

Cuarta Actualización: 02-10-2023 20:39 pm
- Se agregó que al darle clic al boton de reporte se cierre sesión. Luego se cambiará

Quinta Actualización: 2023-10-03 04:28am
- Se terminaron los spinners de nuevo registro
- Se regreso el AndroidManifest a una version anterior, debido a problemas con el "SplashActivity"

Sexta (Última) Actualización: 2023-10-03 06:14 am
- Se creo el Bottom Sheet, y el Chip Group del nuevo registro

## Para Guardar el proyecto
Presionar la flecha verde en la parte superior derecha de la sección "Git" o CTRL + K
Dar clic en el boton "Commit and push".

si se puede anotar una descripción (De preferencia la fecha en formato aa-mm-dd hh:mmam/pm) 
y despues un breve resumen de que se hizo

## Para Actualizar el proyecto
Siempre al abrir el proyecto dar clic en la flecha azul en la sección "Git" o CTRL + T
