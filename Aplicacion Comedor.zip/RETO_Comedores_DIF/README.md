# RETO_Comedores_DIF
Primera subida de el proyecto 24-09-2023 07:45pm

## Para Guardar el proyecto
Presionar la flecha verde en la parte superior derecha de la sección "Git" o CTRL + K
Dar clic en el boton "Commit and push".

si se puede anotar una descripción (De preferencia la fecha en formato aa-mm-dd hh:mmam/pm) 
y despues un breve resumen de que se hizo

## Para Actualizar el proyecto
Siempre al abrir el proyecto dar clic en la flecha azul en la sección "Git" o CTRL + T
